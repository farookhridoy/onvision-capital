<div class="text-center">
    <div class="row">
        <div class="col-12">
            <h3 class="font-weight-bold">4 Steps to Funding</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <p class="text-center">Thank you for placing your trust in us. Please take a few minutes to complete the form below. We will process your request in 1-4 business hours.</p>
        </div>
    </div>
</div>