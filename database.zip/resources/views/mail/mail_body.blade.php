<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>{{$title}}</title>
</head>
<body>
  <p style="font-size:16px;font-weight:500">Hi There,</p>
  <p style="font-size:16px;font-weight:500">Hope you are well.Thank you for placing your trust in us. Please take a few minutes to complete the form below. We will process your request in 1-4 business hours</p>
 
  <p style="font-size:16px;font-weight:500">Yours truly,</p>
  <p style="font-size:14px">Onvision Capital</p>
  <p style="margin-top:10px"></p>
</body>
</html>